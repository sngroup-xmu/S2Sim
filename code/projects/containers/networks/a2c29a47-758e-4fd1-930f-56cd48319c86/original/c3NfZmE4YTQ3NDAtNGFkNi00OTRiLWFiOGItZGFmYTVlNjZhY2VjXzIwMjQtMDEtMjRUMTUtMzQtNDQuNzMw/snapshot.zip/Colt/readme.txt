改paris.cfg
变为：
strasbourg-paris-lille-ghent-brussels-antwerp-thetthague